using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("������� ������:");
        string input = Console.ReadLine();
        string processedString = ProcessString(input);
        Console.WriteLine("������������ ������: " + processedString);
    }

    static string ProcessString(string input)
    {
        string processedString;

        if (input.Length % 2 == 0) 
        {
            int halfLength = input.Length / 2;
            string firstHalf = input.Substring(0, halfLength);
            string secondHalf = input.Substring(halfLength);
            string reversedFirstHalf = ReverseString(firstHalf);
            string reversedSecondHalf = ReverseString(secondHalf);
            processedString = reversedFirstHalf + reversedSecondHalf;
        }
        else 
        {
            string reversedInput = ReverseString(input);
            processedString = reversedInput + input;
        }

        return processedString;
    }

    static string ReverseString(string input)
    {
        char[] charArray = input.ToCharArray();
        Array.Reverse(charArray);
        return new string(charArray);
    }
}